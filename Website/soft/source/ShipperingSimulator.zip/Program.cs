﻿using System;

namespace ShipperingSimulator
{
    class Simulator
    {
        public static void Main()
        {
            Console.WriteLine("Welcome to the Shippering Simulator!\nPress any key when ready\ncopyright leksev softare labs, 2025");
            Console.ReadKey();
            Console.Clear();
            bool Shippering = true;

            // shippering cycle
            while(Shippering)
            {
                Console.Write("First love object <3: ");
                string object1 = Console.ReadLine();
                string ShipObj1;
                ShipObj1 = object1.Substring(0, object1.Length - 2);

                // cropping for pairing
                switch (object1.Length)
                {
                    case >= 9:
                        ShipObj1 = object1.Substring(0, object1.Length - 5);
                        break;
                    case 8:
                        ShipObj1 = object1.Substring(0, object1.Length - 4);
                        break;
                    case 4:
                        ShipObj1 = object1.Substring(0, object1.Length - 1);
                        break;
                    case 3:
                        ShipObj1 = object1.Substring(0, object1.Length - 1);
                        break;
                    case 2:
                        ShipObj1 = object1.Substring(0, object1.Length - 0);
                        break;
                    case 1:
                        ShipObj1 = object1.Substring(0, object1.Length - 0);
                        break;
                    case 0:
                        Console.WriteLine("Invalid name!");
                        continue;
                }

                Console.Write("Second love object <3: ");
                string object2 = Console.ReadLine();
                string ShipObj2;
                ShipObj2 = object2.Substring(2);

                // cropping for pairing
                switch (object2.Length)
                {
                    case >= 9:
                        ShipObj2 = object2.Substring(5);
                        break;
                    case 8:
                        ShipObj2 = object2.Substring(4);
                        break;
                    case 4:
                        ShipObj2 = object2.Substring(1);
                        break;
                    case 3:
                        ShipObj2 = object2.Substring(1);
                        break;
                    case 2:
                        ShipObj2 = object2.Substring(0);
                        break;
                    case 1:
                        ShipObj2 = object2.Substring(0);
                        break;
                    case 0:
                        Console.WriteLine("Invalid name!");
                        continue;
                }

                Console.WriteLine("Shippering...");

                string Ship = ShipObj1 + ShipObj2;

                Console.WriteLine($"SHIP DONE! {Ship} Love each other tenderly:3");
                Console.Write("Continue Shippering? (y/n): ");
                var Key = Console.ReadKey();

                if(Key.Key == ConsoleKey.Y)
                {
                    Console.Clear();
                    continue;
                } else
                {
                    Shippering = false;
                }
            }
        }
    }
}